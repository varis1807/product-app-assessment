package com.Products.Products.service.impl;

import com.Products.Products.dtos.CreateProductRequest;
import com.Products.Products.dtos.UpdateProductRequest;
import com.Products.Products.model.ProductEntity;
import com.Products.Products.repository.ProductRepository;
import com.Products.Products.service.ProductService;
import com.Products.Products.utils.ProductNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Override
    public List<ProductEntity> getAllProducts() {
        return productRepository.findAll();
    }

    @Override
    public ProductEntity getProductById(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new ProductNotFoundException(id));
    }

    @Override
    public ResponseEntity<?> createProduct(CreateProductRequest createProductRequest) {
        System.out.print("Creating Product: " + createProductRequest);
        ProductEntity savedProduct = ProductEntity.builder()
                .name(createProductRequest.getName())
                .price(createProductRequest.getPrice())
                .description(createProductRequest.getDescription())
                .build();
        productRepository.save(savedProduct);
        return new ResponseEntity<>(savedProduct, HttpStatus.CREATED);
    }

    @Override
    public ProductEntity updateProduct(Long id, UpdateProductRequest updateProductRequest) {
        // Fetch existing product from the database
        ProductEntity existingProduct = productRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Product not found"));
        // Update fields
        existingProduct.setName(updateProductRequest.getName());
        existingProduct.setPrice(updateProductRequest.getPrice());
        existingProduct.setDescription(updateProductRequest.getDescription());
        // Save and return the updated product
        return productRepository.save(existingProduct);
    }

    @Override
    public void deleteProduct(Long id) {
        if (!productRepository.existsById(id)) {
            throw new RuntimeException("Product not found");
        }
        productRepository.deleteById(id);
    }
}
