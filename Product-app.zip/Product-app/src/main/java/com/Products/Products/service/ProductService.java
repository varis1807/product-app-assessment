package com.Products.Products.service;

import com.Products.Products.dtos.CreateProductRequest;
import com.Products.Products.dtos.UpdateProductRequest;
import com.Products.Products.model.ProductEntity;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface ProductService {
    List<ProductEntity> getAllProducts();

    ProductEntity getProductById(Long id);

    ResponseEntity<?> createProduct(CreateProductRequest createProductRequest);

    ProductEntity updateProduct(Long id, UpdateProductRequest updateProductRequest);

    void deleteProduct(Long id);
}
