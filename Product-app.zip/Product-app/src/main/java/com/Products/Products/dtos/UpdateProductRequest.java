package com.Products.Products.dtos;

import lombok.Data;

@Data
public class UpdateProductRequest {
    private String name;
    private Double price;
    private String description;
}
